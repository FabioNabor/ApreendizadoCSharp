import pandas as pd

df = pd.read_csv('LogonOrgs.txt',sep='\t', index_col=0)
df['UsuarioSenha'] = df['UsuarioSenha'].apply(eval)

operador_scpc = df.at['Scpc', 'UsuarioSenha']['Operador']
senha_scpc = df.at['Scpc', 'UsuarioSenha']['Senha']

operador_serasa = df.at['Serasa', 'UsuarioSenha']['Operador'] 
senha_serasa = df.at['Serasa', 'UsuarioSenha']['Senha']  

operador_spc = df.at['SpcBrasil', 'UsuarioSenha']['Operador'] 
senha_spc = df.at['SpcBrasil', 'UsuarioSenha']['Senha']
chave_spc = df.at['SpcBrasil', 'UsuarioSenha']['Chave']

LogonsUser = {
    'UsuarioSenha':{
        'Scpc': {
            'Operador': {operador_scpc},
            'Senha': {senha_scpc}
        },
        'Serasa': {
            'Operador': {operador_serasa},
            'Senha': {senha_serasa}
        },
        'SpcBrasil': {
            'Operador': {operador_spc},
            'Senha': {senha_spc},
            'Chave': {chave_spc}
            
        }
    }
}









