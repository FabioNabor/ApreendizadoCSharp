

class XpatchSite:
    LoginScpcXpatch = {
        'site_login': 'https://www.scpc.inf.br/cgi-bin/spcnweb?HTML_PROGRAMA=md000001.int',
        'cod_operador_patch':  '/html/body/div/form/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]/input',
        'senha_operador_patch': '/html/body/div/form/table/tbody/tr[2]/td/table/tbody/tr[2]/td[2]/input',
        'button_login_patch': '/html/body/div/form/table/tbody/tr[2]/td/table/tbody/tr[4]/td/label/input'
    }
    
    LoginSerasaXpatch = {
        'site_login': 'https://sitenet.serasa.com.br/Logon/',
        'cod_operador_patch':  '/html/body/section[1]/div/div/div[2]/div/form/div[1]/div/input',
        'senha_operador_patch': '/html/body/section[1]/div/div/div[2]/div/form/div[2]/div[1]/input',
        'button_login_patch': '/html/body/section[1]/div/div/div[2]/div/form/div[3]/a'
    }
    
    LoginSpcBrasilXpatch = {
        'site_login': 'https://sistema.spc.org.br/spc/controleacesso/autenticacao/entry.action',
        'cod_operador_patch':  '/html/body/div/form/div[1]/div[2]/div/div[1]/div[2]/div[1]/input',
        'senha_operador_patch': '/html/body/div/form/div[1]/div[2]/div/div[1]/div[2]/div[2]/input',
        'button_avanc_patch': '/html/body/div/form/div[1]/div[2]/div/div[1]/div[2]/div[4]/div/button/span',
        'chave_patch': '',
        'button_login_patch': ''
    }
    
class Consulta:
    ConsultaScpcXpatch = {
        'consulta_spca': '/html/body/div[3]/table/tbody/tr/td/ul/li[6]/a',
        'consulta_manutencoes': '/html/body/div[9]/table/tbody/tr/td/ul/li[2]/a',
        'consulta_pessoafisica': '/html/body/div/ul[1]/li[1]',

        'consulta_insert_cpf': '/html/body/div[2]/div/div/div[2]/div/div[1]/form/div/div/div[2]/div/div[1]/div/div/input',
        'consulta_enter': '/html/body/div[2]/div/div/div[2]/div/div[2]/div/button'
    }
    ConsultaSerasaXpatch = {
        'consulta_cobranca_siscovem': '',
        'consulta_penfin': ''
    }

