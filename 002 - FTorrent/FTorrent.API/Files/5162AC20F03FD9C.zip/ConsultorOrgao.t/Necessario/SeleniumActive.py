from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from Patchs import XpatchSite
from Patchs import Consulta
from Logons import LogonsUser


class ExecutorCentral:
    def __init__(self):
        
        self.InfoLp()
        self.LoginSite('SCPC')
        self.TelaDeConulta('SCPC')
        time.sleep(10)
        
        
    def InfoLp(self):    
        ll = LogonsUser
        xscpc = XpatchSite.LoginScpcXpatch
        xserasa = XpatchSite.LoginSerasaXpatch
        xspc = XpatchSite.LoginSpcBrasilXpatch
        #scpc
        self.scpcuser = ll['UsuarioSenha']['Scpc']['Operador']
        self.scpcsenha = ll['UsuarioSenha']['Scpc']['Senha']
        self.scpcsite = xscpc['site_login']
        self.cod_operador_patch = xscpc['cod_operador_patch']
        self.senha_operador_patch = xscpc['senha_operador_patch']
        self.button_login_patch = xscpc['button_login_patch']
        #serasa
        self.serasauser = ll['UsuarioSenha']['Serasa']['Operador']
        self.serasasenha = ll['UsuarioSenha']['Serasa']['Senha']
        self.serasasite = xserasa['site_login']
        self.scod_operador_patch = xserasa['cod_operador_patch']
        self.ssenha_operador_patch = xserasa['senha_operador_patch']
        self.sbutton_login_patch = xserasa['button_login_patch']
        #spcbrasil
        self.spcuser = ll['UsuarioSenha']['SpcBrasil']['Operador']
        self.spcsenha = ll['UsuarioSenha']['SpcBrasil']['Senha']
        self.spcchave = ll['UsuarioSenha']['SpcBrasil']['Chave']
        self.spcsite = xspc['site_login']
        self.spccod_operador_patch = xspc['cod_operador_patch']
        self.spcsenha_operador_patch = xspc['senha_operador_patch']
        self.button_avanc_patch = xspc['button_avanc_patch']
        self.chave_patch = xspc['chave_patch']
        self.spcbutton_login_patch = xspc['button_login_patch']
    
    def LoginSite(self, orgao):      
        try:             
            if orgao == 'SCPC': 
                self.driverscpc = webdriver.Chrome() 
                self.driverscpc.get(self.scpcsite)
                self.driverscpc.find_element(By.XPATH, self.cod_operador_patch).send_keys(self.scpcuser)
                self.driverscpc.find_element(By.XPATH, self.senha_operador_patch).send_keys(self.scpcsenha)
                self.driverscpc.find_element(By.XPATH, self.button_login_patch).click()
                
            elif orgao == 'SERASA':            
                self.driver = webdriver.Chrome()
                self.driver.get(self.serasasite)
                self.driver.find_element(By.XPATH, self.scod_operador_patch).send_keys(self.serasauser)
                self.driver.find_element(By.XPATH, self.ssenha_operador_patch).send_keys(self.serasasenha)
                self.driver.find_element(By.XPATH, self.sbutton_login_patch).click()
            elif orgao == 'SPC':
                self.driver = webdriver.Chrome()
                self.driver.get(self.spcsite)
                self.driver.find_element(By.XPATH, self.spccod_operador_patch).send_keys(self.spcuser)
                self.driver.find_element(By.XPATH, self.spcsenha_operador_patch).send_keys(self.spcsenha)
                self.driver.find_element(By.XPATH, self.button_avanc_patch).click()
                self.driver.find_element(By.XPATH, self.chave_patch)
                self.driver.find_element(By.XPATH, self.spcbutton_login_patch).click()
        except:
            pass
    
    def Aguardar_render_xpath(nav, xpathcode:str) -> None:
        WebDriverWait(nav, 10).until(EC.visibility_of_element_located((By.XPATH, xpathcode)))


    def entrar_iframe(self, nav,xpath_iframe):
        #Aguardar_render_xpath(navegador,xpath_iframe)
        iframe = nav.find_element(By.XPATH,xpath_iframe)
        nav.switch_to.frame(iframe)
        return iframe


    def TelaDeConulta(self, orgao): #IR ATÉ A TELA ONDE SERA FEITA A CONSULTA
        if orgao == 'SCPC':
            self.driverscpc.find_element(By.XPATH, '/html/body/div[3]/table/tbody/tr/td/ul/li[6]/a').click()
            time.sleep(2)
            self.driverscpc.find_element(By.XPATH, '/html/body/div[9]/table/tbody/tr/td/ul/li[2]/a').click()
            time.sleep(2)
            abs = self.entrar_iframe(self.driverscpc, '/html/body/div[15]/iframe[1]')
            print(abs)
            # Agora você pode interagir com os elementos dentro do formulário, por exemplo, clicar no link
            
        elif orgao == 'SERASA': 
              pass         
            

        elif orgao == 'SPC':
             pass
            
            
            
    def EfetuandoConsulta(self, cpf): #FAZER CONSULTA E RETORNAR O RESULTADO OBTIDO
        pass
    
    def BackConsulta(self, orgao): #VOLTAR A TELA DE CONSULTA PARA CONSULTAR
        pass


    def StartConsulta(self, orgao, cpf):
        pass

      
ExecutorCentral() 
